﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;

namespace Autolandia
{
    public partial class MainWindow : Window
    {
        private readonly HttpClient _httpClient;

        public MainWindow()
        {
            InitializeComponent();
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5098/api/");
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = UsernameTextBox.Text;
                string password = PasswordBox.Password;

                if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Введите логин и пароль");
                    return;
                }

                LoginButton.Content = "Вход...";
                LoginButton.IsEnabled = false;

                var authData = new { Email = email, Password = password };
                string json = JsonSerializer.Serialize(authData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("Users/AuthUser", content);

                if (response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    var user = JsonSerializer.Deserialize<User>(responseContent, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    // Открываем AdminWindow с учетом роли
                    AdminWindow adminWindow = new AdminWindow(user);
                    adminWindow.Show();
                    this.Close();
                }
                else
                {
                    string errorMessage = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Ошибка авторизации: {errorMessage}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex.Message}");
            }
            finally
            {
                // Восстанавливаем кнопку
                LoginButton.Content = "Войти";
                LoginButton.IsEnabled = true;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
    public class User
    {
        public int IdUser { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int RoleUser { get; set; }
        public string UserStatus { get; set; }

        public string FullName => $"{Surname} {Name} {Patronymic}";
        public string RoleName => GetRoleName(RoleUser);

        private string GetRoleName(int roleId)
        {
            return roleId switch
            {
                1 => "Клиент",
                2 => "Менеджер",
                3 => "Бухгалтер",
                4 => "Автомеханик",
                _ => "Пользователь"
            };
        }
    }
}
﻿using System.Windows;
using System.Windows.Controls;
using Autolandia;

namespace Autolandia
{
    public partial class AdminWindow : Window
    {
        private User _currentUser;

        public AdminWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            InitializeInterfaceByRole();
            NavigateToDefaultPage();
        }

        private void InitializeInterfaceByRole()
        {
            switch (_currentUser.RoleUser)
            {
                case 2:
                    InitializeManagerInterface();
                    break;
                case 3:
                    InitializeAccountantInterface();
                    break;
                default:
                    InitializeDefaultInterface();
                    break;
            }
        }

        private void InitializeManagerInterface()
        {
            WindowTitle.Text = "Панель менеджера";
            UserInfoText.Text = $"Менеджер: {_currentUser.Surname} {_currentUser.Name} {_currentUser.Patronymic}";

            ServicesButton.Visibility = Visibility.Visible;
            AddServiceButton.Visibility = Visibility.Visible;
            AccountsButton.Visibility = Visibility.Collapsed;
            ReportsButton.Visibility = Visibility.Collapsed;
        }

        private void InitializeAccountantInterface()
        {
            WindowTitle.Text = "Панель бухгалтера";
            UserInfoText.Text = $"Бухгалтер: {_currentUser.Surname} {_currentUser.Name} {_currentUser.Patronymic}";

            ServicesButton.Visibility = Visibility.Collapsed;
            AddServiceButton.Visibility = Visibility.Collapsed;
            AccountsButton.Visibility = Visibility.Visible;
            ReportsButton.Visibility = Visibility.Visible;
        }

        private void InitializeDefaultInterface()
        {
            WindowTitle.Text = "Панель управления";
            UserInfoText.Text = $"{_currentUser.Surname} {_currentUser.Name} {_currentUser.Patronymic}";

            ServicesButton.Visibility = Visibility.Collapsed;
            AddServiceButton.Visibility = Visibility.Collapsed;
            AccountsButton.Visibility = Visibility.Collapsed;
            ReportsButton.Visibility = Visibility.Collapsed;
        }

        private void NavigateToDefaultPage()
        {
            switch (_currentUser.RoleUser)
            {
                case 2:
                    NavigateToPage("Services");
                    UpdateButtonStyle(ServicesButton);
                    break;
                case 3:
                    NavigateToPage("Accounts");
                    UpdateButtonStyle(AccountsButton);
                    break;
                default:
                    PageTitle.Text = "Добро пожаловать";
                    break;
            }
        }

        private void NavButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is string pageTag)
            {
                NavigateToPage(pageTag);
                UpdateButtonStyle(button);
            }
        }

        private void NavigateToPage(string pageTag)
        {
            switch (pageTag)
            {
                case "Services":
                    PageTitle.Text = "Управление услугами";
                    MainFrame.Navigate(new ServicesPage());
                    break;
                case "AddService":
                    PageTitle.Text = "Добавление услуги";
                    MainFrame.Navigate(new AddService());
                    break;
                case "Accounts":
                    PageTitle.Text = "Управление счетами";
                    MainFrame.Navigate(new AccountsPage());
                    break;
                case "Reports":
                    PageTitle.Text = "Финансовые отчеты";
                    MainFrame.Navigate(new AccountsPage());
                    break;
            }
        }

        private void UpdateButtonStyle(Button activeButton)
        {
            if (ServicesButton.Visibility == Visibility.Visible)
                ServicesButton.Style = (Style)FindResource("NavButtonStyle");
            if (AddServiceButton.Visibility == Visibility.Visible)
                AddServiceButton.Style = (Style)FindResource("NavButtonStyle");
            if (AccountsButton.Visibility == Visibility.Visible)
                AccountsButton.Style = (Style)FindResource("NavButtonStyle");
            if (ReportsButton.Visibility == Visibility.Visible)
                ReportsButton.Style = (Style)FindResource("NavButtonStyle");

            activeButton.Style = (Style)FindResource("NavButtonActiveStyle");
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}